import { useState } from 'react';
import { Link } from 'react-router-dom';

export default function Footer() {
  const [email, setEmail]   = useState('');
  const [sent, setSent]     = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (email) { setSent(true); setEmail(''); }
  };

  return (
    <footer className="bg-navy text-white" role="contentinfo">
      <div className="container-wide py-16 md:py-20">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 md:gap-8">

          {/* Brand */}
          <div className="md:col-span-1">
            <Link to="/" className="font-display font-bold text-xl text-white hover:text-teal transition-colors">
              Stronger Every Decade
            </Link>
            <p className="mt-4 text-sm text-white/60 leading-relaxed">
              Building strength that lasts.
            </p>
          </div>

          {/* Programmes */}
          <div>
            <p className="eyebrow text-white/40 mb-4">Programmes</p>
            <ul className="flex flex-col gap-3 text-sm text-white/70">
              {['30s · Foundation','40s · Transition','50s · Rebuild','60s+ · Longevity'].map(t => (
                <li key={t}>
                  <Link to="/programmes" className="hover:text-teal transition-colors">{t}</Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Navigate */}
          <div>
            <p className="eyebrow text-white/40 mb-4">Navigate</p>
            <ul className="flex flex-col gap-3 text-sm text-white/70">
              {[['About','/about'],['Philosophy','/philosophy'],['Resources','/resources'],['Work With Me','/work-with-me'],['FAQ','/faq']].map(([l,h]) => (
                <li key={h}><Link to={h} className="hover:text-teal transition-colors">{l}</Link></li>
              ))}
            </ul>
          </div>

          {/* Newsletter */}
          <div>
            <p className="font-display text-xl font-semibold mb-2">Stay in it.</p>
            <p className="text-sm text-white/60 mb-6 leading-relaxed">
              Weekly insights on training, longevity, and living well in every decade.
            </p>
            {sent ? (
              <p className="text-teal font-semibold text-sm">You're in. See you next week.</p>
            ) : (
              <form onSubmit={handleSubmit} className="flex flex-col gap-3">
                <input
                  type="email"
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  placeholder="Your email address"
                  required
                  className="bg-transparent border-b border-white/30 focus:border-teal outline-none text-white placeholder-white/40 text-sm py-2 transition-colors"
                  aria-label="Email address for newsletter"
                />
                <button type="submit" className="btn btn-primary text-sm py-2.5 px-6 self-start">
                  Subscribe
                </button>
              </form>
            )}
          </div>
        </div>

        <div className="hr-rule mt-12 mb-8 opacity-20" />

        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 text-xs text-white/40">
          <p>© 2026 Stronger Every Decade. All rights reserved.</p>
          <div className="flex gap-6">
            <Link to="/legal/privacy" className="hover:text-white transition-colors">Privacy Policy</Link>
            <Link to="/legal/terms"   className="hover:text-white transition-colors">Terms of Use</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
