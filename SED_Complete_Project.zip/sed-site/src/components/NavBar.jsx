import { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';

const navLinks = [
  { label: 'About',        href: '/about' },
  { label: 'Philosophy',   href: '/philosophy' },
  { label: 'Programmes',   href: '/programmes' },
  { label: 'Resources',    href: '/resources' },
];

export default function NavBar() {
  const [scrolled, setScrolled]     = useState(false);
  const [menuOpen, setMenuOpen]     = useState(false);
  const location = useLocation();
  const isHome = location.pathname === '/';

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 80);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => setMenuOpen(false), [location.pathname]);

  const navBg = isHome && !scrolled
    ? 'bg-transparent'
    : 'bg-white border-b border-[#D0DDE8]';
  const textColor = isHome && !scrolled ? 'text-white' : 'text-navy';
  const logoColor = isHome && !scrolled ? 'text-white' : 'text-navy';

  return (
    <>
      <nav
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-200 ${navBg}`}
        role="navigation"
        aria-label="Main navigation"
      >
        <div className="container-site h-16 flex items-center justify-between">
          {/* Logo */}
          <Link
            to="/"
            className={`font-display font-bold text-lg tracking-wide ${logoColor} transition-colors`}
            aria-label="Stronger Every Decade — home"
          >
            Stronger Every Decade
          </Link>

          {/* Desktop links */}
          <ul className="hidden md:flex items-center gap-8 list-none m-0 p-0">
            {navLinks.map(({ label, href }) => {
              const active = location.pathname === href;
              return (
                <li key={href}>
                  <Link
                    to={href}
                    className={`font-sans font-semibold text-sm transition-colors relative
                      ${textColor}
                      ${active ? 'after:absolute after:bottom-[-4px] after:left-0 after:right-0 after:h-[2px] after:bg-teal' : ''}
                      hover:text-teal`}
                  >
                    {label}
                  </Link>
                </li>
              );
            })}
          </ul>

          {/* CTA */}
          <div className="hidden md:block">
            <Link
              to="/work-with-me"
              className={`btn btn-secondary text-sm py-2.5 px-6
                ${isHome && !scrolled ? 'border-white text-white hover:bg-white hover:text-navy' : ''}`}
            >
              Work With Me
            </Link>
          </div>

          {/* Mobile hamburger */}
          <button
            className={`md:hidden flex flex-col gap-[5px] p-2 ${textColor}`}
            onClick={() => setMenuOpen(o => !o)}
            aria-label={menuOpen ? 'Close menu' : 'Open menu'}
            aria-expanded={menuOpen}
          >
            <span className={`block w-6 h-[1.5px] bg-current transition-transform duration-200 ${menuOpen ? 'rotate-45 translate-y-[6.5px]' : ''}`} />
            <span className={`block w-6 h-[1.5px] bg-current transition-opacity duration-200 ${menuOpen ? 'opacity-0' : ''}`} />
            <span className={`block w-6 h-[1.5px] bg-current transition-transform duration-200 ${menuOpen ? '-rotate-45 -translate-y-[6.5px]' : ''}`} />
          </button>
        </div>
      </nav>

      {/* Mobile menu */}
      <div
        className={`fixed inset-0 z-40 bg-navy flex flex-col justify-center px-8 transition-opacity duration-300
          ${menuOpen ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'}`}
        aria-hidden={!menuOpen}
      >
        <ul className="flex flex-col gap-8 list-none m-0 p-0">
          {navLinks.map(({ label, href }) => (
            <li key={href}>
              <Link
                to={href}
                className="font-display text-4xl font-bold text-white hover:text-teal transition-colors"
              >
                {label}
              </Link>
            </li>
          ))}
          <li>
            <Link
              to="/work-with-me"
              className="font-display text-4xl font-bold text-gold hover:text-teal transition-colors"
            >
              Work With Me
            </Link>
          </li>
        </ul>
      </div>
    </>
  );
}
