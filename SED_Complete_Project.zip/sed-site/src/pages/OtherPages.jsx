import { Reveal, Eyebrow, PullQuote, BlogCard, EmailCapture } from '../components/UI';
import { blogPosts } from '../data/siteData';
import { Link } from 'react-router-dom';

// ── ABOUT ─────────────────────────────────────────────────────────────────────
export function AboutPage() {
  return (
    <main id="main">
      <section className="pt-32 pb-16 bg-[#F8F4EF]">
        <div className="container-narrow">
          <Reveal>
            <Eyebrow>About</Eyebrow>
            <h1 className="display-1 mb-4">Built from the inside out.</h1>
          </Reveal>
        </div>
      </section>

      <section className="section-pad">
        <div className="container-narrow">
          <Reveal>
            <p className="body-lg mb-6">
              This programme exists because I needed it and it did not.
            </p>
            <p className="body-lg mb-6">
              I was a woman in midlife with a professional background in [field],
              a lifetime of movement, and no framework that made sense for the body I was actually living in.
              The science existed. The application did not. So I built it.
            </p>
          </Reveal>
          <Reveal delay={80}>
            <PullQuote>
              The science existed. The application did not. So I built it.
            </PullQuote>
          </Reveal>
          <Reveal delay={100}>
            <h2 className="display-3 mb-6 mt-12">The methodology</h2>
            <p className="body-lg mb-6">
              Stronger Every Decade is built on a single premise: the body does not decline with age so much as it changes.
              Those changes carry specific information. The right programme reads that information and works with it.
            </p>
            <p className="body-lg mb-10">
              Every programme I design starts with physiology, not preference.
              What does the research show for women in this decade? What does clinical practice reveal?
              What do clients report when the science is applied correctly?
            </p>
          </Reveal>

          <Reveal delay={120}>
            <h2 className="display-3 mb-6">Who I work with</h2>
            <p className="body-lg mb-10">
              Women in their 30s, 40s, 50s, and 60s who are done guessing.
              Who want to understand what is happening in their body and train accordingly.
              Who are building a practice for the next twenty years, not a transformation for the next twelve weeks.
            </p>
          </Reveal>

          <Reveal delay={140}>
            <div className="border-t border-[#D0DDE8] pt-10">
              <p className="font-sans font-semibold text-navy text-lg mb-1">[Founder Name]</p>
              <p className="text-xs text-mid mb-8">[Certification] · [Years of practice] · [Media / credential]</p>
              <Link to="/programmes" className="btn btn-primary text-sm py-3 px-8">See the Programmes</Link>
            </div>
          </Reveal>
        </div>
      </section>
    </main>
  );
}

// ── RESOURCES ─────────────────────────────────────────────────────────────────
export function ResourcesPage() {
  return (
    <main id="main">
      <section className="pt-32 pb-16 bg-[#F8F4EF]">
        <div className="container-standard">
          <Reveal>
            <Eyebrow>Resources</Eyebrow>
            <h1 className="display-1 mb-4">Free, expert guidance.</h1>
            <p className="body-lg">Start your journey before you invest in a programme.</p>
          </Reveal>
        </div>
      </section>

      {/* Lead magnet */}
      <section className="section-pad bg-navy">
        <div className="container-standard">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <Reveal>
              <Eyebrow className="text-gold">Free download</Eyebrow>
              <h2 className="display-3 text-white mb-4">The Decade-by-Decade Strength Guide</h2>
              <p className="text-white/60 body-md">
                How training changes across the decades — and exactly how to adjust yours to match where you are right now.
                Written for women who are done guessing.
              </p>
            </Reveal>
            <Reveal delay={100}>
              <EmailCapture dark={true} />
            </Reveal>
          </div>
        </div>
      </section>

      {/* Blog */}
      <section className="section-pad">
        <div className="container-standard">
          <Reveal>
            <Eyebrow>Articles</Eyebrow>
            <h2 className="display-3 mb-10">From the journal</h2>
          </Reveal>
          <div className="flex flex-col gap-10">
            {blogPosts.map((p, i) => <BlogCard key={p.id} post={p} delay={i * 80} />)}
          </div>
        </div>
      </section>

      {/* Newsletter */}
      <section className="section-pad bg-[#F8F4EF]">
        <div className="container-narrow text-center">
          <Reveal>
            <h2 className="display-3 mb-4">Stay in it.</h2>
            <p className="body-md mb-8">Weekly insights on training, longevity, and living well in every decade.</p>
            <div className="flex justify-center">
              <EmailCapture label="Subscribe" placeholder="Your email address" />
            </div>
            <p className="text-xs text-mid mt-4">Weekly, when we have something worth saying.</p>
          </Reveal>
        </div>
      </section>
    </main>
  );
}

// ── WORK WITH ME ──────────────────────────────────────────────────────────────
export function WorkWithMePage() {
  return (
    <main id="main">
      <section className="pt-32 pb-16 bg-[#F8F4EF]">
        <div className="container-standard">
          <Reveal>
            <Eyebrow>Work With Me</Eyebrow>
            <h1 className="display-1 mb-4">
              Let's find the right level of support for you.
            </h1>
            <p className="body-lg max-w-[560px]">
              Choose the level of support that fits your life right now.
              No pressure. No upsell. The right fit is the only goal.
            </p>
          </Reveal>
        </div>
      </section>

      {/* Options */}
      <section className="section-pad">
        <div className="container-wide">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              {
                label: 'Self-paced',
                title: 'Programme + Guide',
                desc: 'The complete decade-specific programme with detailed guidance, progressions, and recovery protocols. Full access, your pace.',
                price: 'From £[X]',
                cta: 'Enrol now',
              },
              {
                label: 'Group',
                title: 'Group Programme',
                desc: 'The programme with bi-weekly group calls, community access, and collective accountability. Limited to [X] women per cohort.',
                price: 'From £[X]',
                cta: 'Apply to join',
              },
              {
                label: '1:1 Coaching',
                title: 'Private Coaching',
                desc: 'Full programme plus weekly 1:1 sessions, direct messaging access, and a fully individualised progression plan.',
                price: 'From £[X]',
                cta: 'Book a call first',
              },
            ].map((opt, i) => (
              <Reveal key={opt.title} delay={i * 80}>
                <div className="card flex flex-col h-full">
                  <span className="decade-badge mb-4 self-start">{opt.label}</span>
                  <h3 className="font-display text-2xl font-semibold text-navy mb-3">{opt.title}</h3>
                  <p className="body-md mb-6 flex-grow">{opt.desc}</p>
                  <p className="font-sans font-semibold text-navy mb-6">{opt.price}</p>
                  <Link to="/programmes" className="btn btn-primary text-sm py-3 px-6 self-start">{opt.cta}</Link>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* Discovery call */}
      <section className="section-pad bg-[#EFF6F6]">
        <div className="container-narrow">
          <Reveal>
            <Eyebrow>Discovery call</Eyebrow>
            <h2 className="display-3 mb-4">Not sure which option fits?</h2>
            <p className="body-lg mb-8">
              Book a free 20-minute call. We will talk through where you are, what you are looking for,
              and which level of support makes sense. No sales pressure. Just clarity.
            </p>
            <Link to="/contact" className="btn btn-primary text-sm py-3.5 px-10">
              Book a free discovery call
            </Link>
            <p className="text-xs text-mid mt-4">No commitment required. 20 minutes. A calendar link will follow by email.</p>
          </Reveal>
        </div>
      </section>

      {/* Closing */}
      <section className="section-pad bg-navy">
        <div className="container-narrow text-center">
          <Reveal>
            <h2 className="display-3 text-white mb-4">Ready?</h2>
            <p className="text-white/60 body-md mb-8">The right programme is the one you keep doing.</p>
            <Link to="/programmes" className="btn btn-primary bg-teal border-teal text-sm py-3.5 px-10">
              Find your programme
            </Link>
          </Reveal>
        </div>
      </section>
    </main>
  );
}

// ── 404 ────────────────────────────────────────────────────────────────────────
export function NotFoundPage() {
  return (
    <main id="main" className="min-h-screen flex items-center justify-center bg-[#F8F4EF]">
      <div className="container-narrow text-center py-24">
        <p className="eyebrow mb-4">404</p>
        <h1 className="display-2 mb-6">Page not found.</h1>
        <p className="body-lg mb-10">That page doesn't seem to exist. Let's get you back on track.</p>
        <Link to="/" className="btn btn-primary text-sm py-3.5 px-10">Return home</Link>
      </div>
    </main>
  );
}
