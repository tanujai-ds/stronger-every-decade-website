import { programs, faqs } from '../data/siteData';
import { Reveal, Eyebrow, ProgrammeCard, FAQItem } from '../components/UI';
import { Link } from 'react-router-dom';

export default function ProgrammesPage() {
  return (
    <main id="main">

      {/* Header */}
      <section className="pt-32 pb-16 bg-[#F8F4EF]">
        <div className="container-standard">
          <Reveal>
            <Eyebrow>Programmes</Eyebrow>
            <h1 className="display-1 mb-4">Find your programme.</h1>
            <p className="body-lg max-w-[560px]">
              Each programme is built for a specific decade of life —
              its physiology, its hormonal context, and its particular demands.
              Not adapted. Designed.
            </p>
          </Reveal>
        </div>
      </section>

      {/* Assessment prompt */}
      <section className="py-8 bg-[#EFF6F6] border-b border-[#D0DDE8]">
        <div className="container-standard">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <p className="font-sans text-navy font-semibold">Not sure where to begin?</p>
            <Link to="/programmes/assessment" className="btn btn-secondary text-sm py-2.5 px-6">
              Take the 3-minute assessment
            </Link>
          </div>
        </div>
      </section>

      {/* Programme grid */}
      <section className="section-pad-lg">
        <div className="container-wide">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
            {programs.map((p, i) => (
              <ProgrammeCard key={p.id} programme={p} delay={i * 80} />
            ))}
          </div>

          {/* Comparison table */}
          <Reveal>
            <div className="container-standard px-0">
              <h2 className="display-3 mb-8">Compare at a glance</h2>
              <div className="overflow-x-auto">
                <table className="w-full text-sm border border-[#D0DDE8]">
                  <thead>
                    <tr className="bg-navy text-white">
                      <th className="text-left p-4 font-sans font-semibold">Attribute</th>
                      {programs.map(p => (
                        <th key={p.id} className="text-left p-4 font-sans font-semibold">{p.decade}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {[
                      ['Format', programs.map(p => p.format)],
                      ['Duration', programs.map(p => p.duration)],
                      ['Support', programs.map(p => p.support)],
                    ].map(([label, values], ri) => (
                      <tr key={label} className={ri % 2 === 0 ? 'bg-[#EFF6F6]' : 'bg-white'}>
                        <td className="p-4 font-sans font-semibold text-navy">{label}</td>
                        {values.map((v, ci) => (
                          <td key={ci} className="p-4 text-slate">{v}</td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </Reveal>
        </div>
      </section>

      {/* FAQ */}
      <section className="section-pad bg-[#F8F4EF]">
        <div className="container-narrow">
          <Reveal>
            <Eyebrow>Before you enrol</Eyebrow>
            <h2 className="display-3 mb-10">Common questions</h2>
          </Reveal>
          {faqs.map((f, i) => <FAQItem key={i} faq={f} index={i} />)}
        </div>
      </section>

      {/* CTA */}
      <section className="section-pad bg-navy">
        <div className="container-narrow text-center">
          <Reveal>
            <h2 className="display-3 text-white mb-6">Ready to find your programme?</h2>
            <p className="text-white/60 body-md mb-8">
              Begin with a free discovery call or enrol directly.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link to="/work-with-me" className="btn btn-primary bg-teal border-teal text-sm py-3.5 px-10">
                Book a discovery call
              </Link>
              <Link to="/work-with-me" className="btn btn-secondary border-white/30 text-white hover:bg-white hover:text-navy text-sm py-3.5 px-8">
                Enrol directly
              </Link>
            </div>
          </Reveal>
        </div>
      </section>

    </main>
  );
}
