import { programs, testimonials, faqs } from '../data/siteData';
import { Reveal, Eyebrow, ProgrammeCard, TestimonialCard, FAQItem, EmailCapture } from '../components/UI';
import { Link } from 'react-router-dom';

const decades = ['30s', '40s', '50s', '60s+'];

export default function HomePage() {
  return (
    <main id="main">

      {/* ── S01  HERO ─────────────────────────────────────────────────── */}
      <section
        className="relative min-h-screen flex flex-col justify-center bg-navy overflow-hidden"
        aria-label="Hero"
      >
        {/* Subtle texture overlay */}
        <div className="absolute inset-0 opacity-[0.04]"
          style={{ backgroundImage: 'repeating-linear-gradient(0deg,transparent,transparent 2px,#fff 2px,#fff 3px)' }} />

        <div className="container-standard relative z-10 pt-32 pb-24">
          {/* Decade markers */}
          <div className="flex gap-3 mb-10 flex-wrap">
            {decades.map(d => (
              <span key={d} className="decade-badge text-teal border-teal/30">{d}</span>
            ))}
          </div>

          {/* Headline */}
          <h1 className="display-1 text-white mb-6 max-w-[720px]">
            Strong at Every Age.<br />Built to Last.
          </h1>

          <p className="font-sans text-white/70 text-lg md:text-xl leading-relaxed mb-10 max-w-[560px]">
            Most fitness advice was designed for a 25-year-old body.
            Yours has decades of intelligence behind it.
            Here, we train accordingly.
          </p>

          {/* CTAs */}
          <div className="flex flex-col sm:flex-row gap-4 items-start">
            <Link to="/programmes" className="btn btn-primary text-sm py-3.5 px-8">
              Explore the Programmes
            </Link>
            <Link to="/resources" className="btn-text text-white hover:text-teal text-sm py-3.5">
              Download the free guide
            </Link>
          </div>

          <p className="mt-8 text-xs text-white/40 font-sans">
            No equipment required to begin. No age limit on what you can build.
          </p>
        </div>
      </section>

      {/* ── S02  PHILOSOPHY STATEMENT ────────────────────────────────── */}
      <section className="section-pad-lg bg-[#F8F4EF]" aria-label="Philosophy">
        <div className="container-narrow">
          <Reveal>
            <Eyebrow>Philosophy</Eyebrow>
            <h2 className="display-2 mb-6">
              Longevity is the goal.<br />Strength is the method.
            </h2>
          </Reveal>
          <Reveal delay={100}>
            <p className="body-lg mb-6">
              We are not chasing a number on a scale or a version of our younger selves.
              We are building bodies that carry us — fully, capably, and without apology — through every decade ahead.
            </p>
            <p className="body-lg mb-12">
              That requires a different kind of training.
              Patient. Intelligent. Built around how your body actually works right now.
            </p>
          </Reveal>

          {/* Three pillars */}
          <Reveal delay={150}>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 pt-8 border-t border-[#D0DDE8]">
              {[
                { label: 'Train for the life you are living.', body: 'Not the body you had at 28.' },
                { label: 'Evidence first, aesthetics second.', body: 'Function and longevity drive every programme decision.' },
                { label: 'Decades are not obstacles.', body: 'They are context. We train with them, not against them.' },
              ].map(({ label, body }) => (
                <div key={label}>
                  <p className="font-sans font-semibold text-navy mb-2">{label}</p>
                  <p className="body-sm">{body}</p>
                </div>
              ))}
            </div>
          </Reveal>
        </div>
      </section>

      {/* ── S03  PROBLEM REFRAME ─────────────────────────────────────── */}
      <section className="section-pad" aria-label="Problem reframe">
        <div className="container-narrow">
          <Reveal>
            <h2 className="display-2 mb-8">
              You have not been failing fitness.<br />
              Fitness has been failing you.
            </h2>
          </Reveal>
          <Reveal delay={100}>
            <p className="body-lg mb-6">
              The programmes you have tried were not designed for a body in its 40s, 50s, or 60s.
              They were designed for peak hormonal output, maximum recovery speed, and a lifestyle with infinite time.
            </p>
            <p className="body-lg mb-6">
              If they felt wrong, they were wrong — for you.
            </p>
            <p className="body-lg mb-10">
              Your body does not need less. It needs different.
              More precision. More recovery intelligence. More respect for the decades of data it already carries.
            </p>
            <p className="font-sans font-semibold text-navy mb-8">
              That is exactly what every Stronger Every Decade programme is built around.
            </p>
            <Link to="/programmes" className="btn-text">See how the programmes work</Link>
          </Reveal>
        </div>
      </section>

      {/* ── S04  SOCIAL PROOF ────────────────────────────────────────── */}
      <section className="section-pad bg-[#EFF6F6]" aria-label="Testimonials">
        <div className="container-wide">
          <Eyebrow className="text-center mb-10">What women are saying</Eyebrow>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {testimonials.map((t, i) => (
              <TestimonialCard key={t.id} testimonial={t} delay={i * 80} />
            ))}
          </div>
          <Reveal delay={200}>
            <p className="text-center text-xs text-mid mt-10">
              Programmes for every decade from 30 to 65+
            </p>
          </Reveal>
        </div>
      </section>

      {/* ── S05  PROGRAMMES PREVIEW ──────────────────────────────────── */}
      <section className="section-pad-lg bg-[#F8F4EF]" aria-label="Programmes">
        <div className="container-wide">
          <div className="container-standard px-0 mb-12">
            <Reveal>
              <Eyebrow>Programmes</Eyebrow>
              <h2 className="display-2 mb-4">
                There is a programme built for exactly where you are right now.
              </h2>
              <p className="body-lg">
                Not a generic plan. Each programme is designed around the specific physiology,
                recovery needs, and goals of women in that decade of life.
              </p>
            </Reveal>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {programs.map((p, i) => (
              <ProgrammeCard key={p.id} programme={p} delay={i * 80} />
            ))}
          </div>

          <Reveal delay={200}>
            <div className="text-center mt-12">
              <p className="body-md mb-4">Not sure which programme is right for your body and goals?</p>
              <Link to="/programmes" className="btn btn-secondary text-sm py-3 px-8">
                Take the 3-minute assessment
              </Link>
              <p className="text-xs text-mid mt-3">No email required. Just clarity.</p>
            </div>
          </Reveal>
        </div>
      </section>

      {/* ── S06  FOUNDER MOMENT ──────────────────────────────────────── */}
      <section className="section-pad" aria-label="Founder">
        <div className="container-standard">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 md:gap-16 items-center">
            <Reveal>
              <Eyebrow>The founder</Eyebrow>
              <h2 className="display-3 mb-6">
                This programme exists because I needed it and it did not.
              </h2>
              <p className="body-lg mb-4">
                The science existed. The application did not. So I built it.
              </p>
              <p className="body-md mb-8">
                Stronger Every Decade is the programme I wish someone had handed me —
                built on evidence, lived experience, and a deep respect for what your
                body is capable of at every age.
              </p>
              <div className="mb-6">
                <p className="font-sans font-semibold text-navy">[Founder Name]</p>
                <p className="text-xs text-mid mt-1">[Certification] · [Years of practice] · [Credential]</p>
              </div>
              <Link to="/about" className="btn-text">Read the full story</Link>
            </Reveal>

            {/* Photo placeholder */}
            <Reveal delay={120}>
              <div className="aspect-[4/5] bg-[#EFF6F6] flex items-center justify-center">
                <p className="text-xs text-mid font-sans text-center px-8">
                  Founder photo<br />
                  <span className="opacity-60">Editorial, unposed</span>
                </p>
              </div>
            </Reveal>
          </div>
        </div>
      </section>

      {/* ── S07  LEAD MAGNET ─────────────────────────────────────────── */}
      <section className="section-pad bg-navy" aria-label="Free resource">
        <div className="container-standard">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <Reveal>
              <Eyebrow className="text-gold">Free resource</Eyebrow>
              <h2 className="display-3 text-white mb-4">
                Not ready for a full programme yet?<br />Start here.
              </h2>
              <p className="text-white/60 body-md mb-2">
                The Decade-by-Decade Strength Guide — practical, free, and written for women who are done guessing.
              </p>
            </Reveal>
            <Reveal delay={120}>
              <EmailCapture dark={true} label="Send me the guide" placeholder="Your email address" />
              <p className="text-xs text-white/35 mt-4 font-sans">
                No spam. Weekly insights only when we have something worth saying.
              </p>
            </Reveal>
          </div>
        </div>
      </section>

      {/* ── FAQ PREVIEW ──────────────────────────────────────────────── */}
      <section className="section-pad" aria-label="FAQ">
        <div className="container-narrow">
          <Reveal>
            <Eyebrow>Common questions</Eyebrow>
            <h2 className="display-3 mb-10">Before you begin</h2>
          </Reveal>
          {faqs.slice(0, 4).map((f, i) => (
            <FAQItem key={i} faq={f} index={i} />
          ))}
        </div>
      </section>

      {/* ── S08  CLOSING CTA ─────────────────────────────────────────── */}
      <section className="section-pad-lg bg-[#F8F4EF]" aria-label="Call to action">
        <div className="container-narrow text-center">
          <Reveal>
            <h2 className="display-2 mb-6">
              Your next decade starts with one decision.
            </h2>
            <p className="body-lg mb-10 max-w-[480px] mx-auto">
              You do not need to overhaul your life.
              You need the right structure, built for your body, starting now.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link to="/programmes" className="btn btn-primary text-sm py-3.5 px-10">
                Find your programme
              </Link>
              <Link to="/work-with-me" className="btn btn-secondary text-sm py-3.5 px-8">
                Book a discovery call
              </Link>
            </div>
            <div className="flex flex-col sm:flex-row gap-4 justify-center mt-5 text-xs text-mid">
              <span>No commitment required for the call.</span>
              <span className="hidden sm:block">·</span>
              <span>Programmes available at multiple investment levels.</span>
            </div>
          </Reveal>
        </div>
      </section>

    </main>
  );
}
