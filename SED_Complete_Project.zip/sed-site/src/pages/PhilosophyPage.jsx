import { principles } from '../data/siteData';
import { Reveal, Eyebrow, PullQuote, PrincipleCard } from '../components/UI';
import { Link } from 'react-router-dom';
import { useEffect, useState } from 'react';

function PageProgress() {
  const [progress, setProgress] = useState(0);
  useEffect(() => {
    const onScroll = () => {
      const doc = document.documentElement;
      const pct  = (window.scrollY / (doc.scrollHeight - doc.clientHeight)) * 100;
      setProgress(Math.min(pct, 100));
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);
  return (
    <div className="fixed top-0 left-0 right-0 h-[2px] z-[60] bg-[#EFF6F6]" role="progressbar" aria-label="Reading progress">
      <div className="h-full bg-teal transition-all duration-75" style={{ width: `${progress}%` }} />
    </div>
  );
}

export default function PhilosophyPage() {
  return (
    <main id="main">
      <PageProgress />

      {/* ── PAGE HEADER ───────────────────────────────────────────────── */}
      <section className="pt-32 pb-16 bg-[#F8F4EF]" aria-label="Page header">
        <div className="container-narrow">
          <Reveal>
            <Eyebrow>Philosophy</Eyebrow>
            <h1 className="display-1 mb-4">The Philosophy</h1>
            <p className="text-xs text-mid font-sans mb-6">8 minute read</p>
            <div className="hr-teal" />
          </Reveal>
        </div>
      </section>

      {/* ── A — INTRODUCTION ──────────────────────────────────────────── */}
      <section className="section-pad" aria-label="Introduction">
        <div className="container-narrow">
          <Reveal>
            <h2 className="display-3 mb-8">
              Most fitness philosophies are not philosophies at all.
            </h2>
          </Reveal>
          <Reveal delay={80}>
            <p className="body-lg mb-6">
              They are collections of preferences dressed in the language of belief.
              Train harder. Eat less. Push through. Burn it down and rebuild.
              These are instructions, not ideas. And for women navigating midlife and beyond,
              instructions without ideas have a long and unhelpful history.
            </p>
            <p className="body-lg mb-6">
              This page exists because the programmes we build here are downstream of something.
              They come from a specific way of understanding the body, time, and what health is actually for.
            </p>
            <p className="body-lg mb-6">
              If you are going to invest your time, your energy, and your trust in this work,
              you deserve to know what we actually believe — not just what we sell.
            </p>
            <p className="font-display italic text-navy text-lg">Read slowly. There is no rush.</p>
          </Reveal>
        </div>
      </section>

      {/* ── B — CORE BELIEF ───────────────────────────────────────────── */}
      <section className="section-pad bg-[#F8F4EF]" aria-label="Core belief">
        <div className="container-narrow">
          <Reveal>
            <Eyebrow>Core belief</Eyebrow>
            <h2 className="display-2 mb-8">
              The body is not a problem to be solved.<br />
              It is a system to be understood.
            </h2>
          </Reveal>
          <Reveal delay={80}>
            <p className="body-lg mb-6">
              This is not a semantic distinction. It changes everything.
            </p>
            <p className="body-lg mb-6">
              When the body is a problem, the goal is to fix it.
              You fight inflammation. You fight fat. You fight ageing.
              You spend your 40s at war with your 30s, and your 50s mourning both.
            </p>
            <p className="body-lg mb-6">
              When the body is a system, the goal is comprehension.
              You learn what it needs. You learn how it adapts.
              You learn that what looks like decline is often miscommunication —
              between what you are asking of it and what it is equipped, right now, to do.
            </p>
          </Reveal>
          <Reveal delay={120}>
            <p className="body-lg mb-6">Stronger Every Decade is built on the second view.</p>
            <p className="font-sans font-semibold text-navy text-lg mb-6">
              Not because it is more optimistic. Because it is more accurate.
            </p>
            <p className="body-lg mb-10">
              The body at 47 is not the body at 27 with something missing.
              It is a different system, with different inputs, different signals,
              and a different — often more sophisticated — capacity for adaptation.
            </p>
            <p className="font-display text-2xl font-semibold text-teal">Train it accordingly.</p>
          </Reveal>
          <Reveal delay={160}>
            <PullQuote>
              The body at 47 is not the body at 27 with something missing.
              It is a different system — with a different, often more sophisticated, capacity for adaptation.
            </PullQuote>
          </Reveal>
        </div>
      </section>

      {/* ── C — SIX PRINCIPLES ────────────────────────────────────────── */}
      <section className="section-pad-lg" aria-label="Six principles">
        <div className="container-wide">
          <div className="container-narrow px-0 mb-16">
            <Reveal>
              <Eyebrow>Six principles</Eyebrow>
              <h2 className="display-2">
                What we believe — expanded.
              </h2>
            </Reveal>
          </div>
          <div className="flex flex-col gap-6">
            {principles.map((p, i) => (
              <PrincipleCard key={p.number} principle={p} index={i} />
            ))}
          </div>
        </div>
      </section>

      {/* ── D — OPERATING PRINCIPLE ───────────────────────────────────── */}
      <section className="section-pad bg-[#F8F4EF]" aria-label="Operating principle">
        <div className="container-narrow">
          <Reveal>
            <Eyebrow>In practice</Eyebrow>
            <h2 className="display-3 mb-6">
              Philosophy without application is biography.
            </h2>
            <p className="body-lg mb-4">
              Every programme decision — the exercises chosen, the progressions built,
              the recovery protocols, the pacing, the support structure — is evaluated
              against a single operating question:
            </p>
          </Reveal>
          <Reveal delay={80}>
            <PullQuote>"Does this serve the woman who will be doing this in ten years?"</PullQuote>
          </Reveal>
          <Reveal delay={120}>
            <p className="body-lg mb-10">
              Not the woman who wants fast results. Not the woman who is training for a moment.
              The woman who is training for a life.
            </p>
          </Reveal>

          {/* Operating table */}
          <Reveal delay={140}>
            <div className="border border-[#D0DDE8] overflow-hidden">
              {[
                ['Longevity as primary goal', 'Joint health, mobility, and bone density are non-negotiable programme pillars — not extras'],
                ['Decades as data', 'Every programme is built for a specific hormonal and physiological context, not a generic population'],
                ['Evidence as foundation', 'Exercise selection is updated as research evolves; we publish our reasoning, not just our recommendations'],
                ['Consistency over intensity', 'Programme design prioritises sessions you will return to over sessions that maximise short-term output'],
                ['Rest as training', 'Recovery days are prescribed, not optional; deload weeks are built in, not added reactively'],
                ['Body as partner', 'Programme language is neutral and functional; no punishment framing, no shame architecture'],
              ].map(([principle, outcome], i) => (
                <div key={principle} className={`grid grid-cols-1 md:grid-cols-3 ${i % 2 === 0 ? 'bg-[#EFF6F6]' : 'bg-white'}`}>
                  <div className="p-5 md:border-r border-[#D0DDE8]">
                    <p className="font-sans font-semibold text-navy text-sm">{principle}</p>
                  </div>
                  <div className="p-5 md:col-span-2">
                    <p className="body-md text-sm">{outcome}</p>
                  </div>
                </div>
              ))}
            </div>
          </Reveal>
        </div>
      </section>

      {/* ── E — CLOSING ───────────────────────────────────────────────── */}
      <section className="section-pad-lg bg-navy" aria-label="Closing statement">
        <div className="container-narrow">
          <Reveal>
            <Eyebrow className="text-gold">Who this is for</Eyebrow>
            <h2 className="display-2 text-white mb-8">
              This is not a programme for everyone.<br />
              It is not trying to be.
            </h2>
          </Reveal>
          <Reveal delay={80}>
            <p className="text-white/70 body-lg mb-6">
              If you are looking for the fastest route to a specific aesthetic outcome,
              there are programmes built for that. We will not compete for that version of your attention.
            </p>
            <p className="text-white/70 body-lg mb-6">
              What we are building here is narrower and, we believe, more durable.
            </p>
          </Reveal>
          <Reveal delay={100}>
            <PullQuote>
              <span className="text-white/90">
                A practice — in the oldest sense of the word. Something you do not complete. Something you inhabit.
              </span>
            </PullQuote>
          </Reveal>
          <Reveal delay={120}>
            <p className="text-white/70 body-lg mb-6">
              The women who work here are not looking for a transformation.
              They have already transformed — many times over, through careers, relationships, losses,
              and reinventions that required forms of strength no programme could have built.
            </p>
            <p className="text-white/70 body-lg mb-10">
              What they are looking for is a physical life that keeps pace with the rest of who they are.
              Capable. Clear-headed. Unimpaired. Strong in the ways that make everything else possible.
            </p>
          </Reveal>
          <Reveal delay={140}>
            <p className="font-display text-2xl text-white font-semibold mb-8">
              If you recognise yourself in this, we built it for you.
            </p>
            <p className="text-white/60 body-md mb-8">
              The programmes are structured by decade. The starting point is wherever you are right now.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link to="/programmes" className="btn btn-primary bg-teal border-teal text-sm py-3.5 px-10">
                Explore the Programmes
              </Link>
              <Link to="/resources" className="btn-text text-white/80 hover:text-teal text-sm py-3.5">
                Download the free guide
              </Link>
            </div>
            <p className="text-xs text-white/35 mt-5">No age requirement. No fitness prerequisite. Only the intention to train for the long run.</p>
          </Reveal>
        </div>
      </section>

    </main>
  );
}
