import { BrowserRouter, Routes, Route, useLocation } from 'react-router-dom';
import { useEffect } from 'react';
import NavBar from './components/NavBar';
import Footer from './components/Footer';
import HomePage from './pages/HomePage';
import PhilosophyPage from './pages/PhilosophyPage';
import ProgrammesPage from './pages/ProgrammesPage';
import { AboutPage, ResourcesPage, WorkWithMePage, NotFoundPage } from './pages/OtherPages';
import './styles/index.css';

function ScrollToTop() {
  const { pathname } = useLocation();
  useEffect(() => { window.scrollTo(0, 0); }, [pathname]);
  return null;
}

function AppShell() {
  return (
    <>
      <ScrollToTop />
      <NavBar />
      <Routes>
        <Route path="/"             element={<HomePage />} />
        <Route path="/about"        element={<AboutPage />} />
        <Route path="/philosophy"   element={<PhilosophyPage />} />
        <Route path="/programmes"   element={<ProgrammesPage />} />
        <Route path="/resources"    element={<ResourcesPage />} />
        <Route path="/work-with-me" element={<WorkWithMePage />} />
        <Route path="*"             element={<NotFoundPage />} />
      </Routes>
      <Footer />
    </>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <AppShell />
    </BrowserRouter>
  );
}
